/**
 * Shared "unread Butler message" state.
 * Single source of truth used by the tab bar's AI CHAT dot and by
 * ButlerLauncherChip's "N NEW" badge — extracted out of FuturisticTabBar.tsx
 * so a standalone chip component can read/subscribe to it without a
 * circular import.
 */

let _count = 0;
const _listeners: Set<(count: number) => void> = new Set();

export function notifyButlerNewMessage() {
  _count += 1;
  _listeners.forEach(fn => { try { fn(_count); } catch {} });
}

export function clearButlerUnread() {
  if (_count === 0) return;
  _count = 0;
  _listeners.forEach(fn => { try { fn(_count); } catch {} });
}

export function getButlerUnreadCount() {
  return _count;
}

/** Returns an unsubscribe function. */
export function subscribeButlerUnread(fn: (count: number) => void): () => void {
  _listeners.add(fn);
  return () => { _listeners.delete(fn); };
}

// Kept for any existing external callers using the old global hook names.
(global as any).__notifyButlerNewMessage = notifyButlerNewMessage;
(global as any).__clearButlerUnread      = clearButlerUnread;
