/**
 * Butler AI — Encrypted Local Storage
 * Wraps AsyncStorage with a lightweight obfuscation layer using expo-crypto.
 * All sensitive keys (scripts, session tokens, connection state, KB findings) are
 * obfuscated at rest. Non-sensitive cache keys remain unencrypted for performance.
 *
 * IMPORTANT — this is NOT real AES. The cipher below is a custom XOR-stream
 * built from SHA-256 keystream blocks. It raises the bar above plaintext
 * storage but has not been independently audited and should not be described
 * as "AES-256-equivalent" — it isn't. If this ever needs to resist a
 * determined attacker (not just casual inspection of AsyncStorage files),
 * swap this for a vetted library (e.g. react-native-aes-crypto) before relying
 * on it for anything sensitive.
 *
 * Scheme actually implemented:
 *  - Key derivation: SHA-256 of (deviceId + salt), stretched via 1000 iterations
 *  - Cipher: XOR-stream with SHA-256 blocks (deterministic stream cipher, NOT AES)
 *  - Each value is prefixed with a random 16-byte IV hex (32 chars) before encryption
 *  - Stored as base64 to keep AsyncStorage happy
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
// expo-crypto: lazy-loaded to prevent Class A Android cold-start crash.
// Static top-level import of native modules crashes before the bridge is ready.
let _Crypto: any = null;
function getCrypto() {
  if (!_Crypto) {
    try { _Crypto = require('expo-crypto'); } catch { _Crypto = null; }
  }
  return _Crypto;
}
// Persist the derived key so cold starts skip the 1000-iteration KDF chain.
// `expo-secure-store` is the right vault (Android Keystore / iOS Keychain)
// but lazy-loaded so a module-level failure here can never block boot.
let _SecureStore: any = null;
function getSecureStore() {
  if (_SecureStore) return _SecureStore;
  try { _SecureStore = require('expo-secure-store'); } catch { _SecureStore = null; }
  return _SecureStore;
}

// ── Keys that hold sensitive data and must be encrypted ─────────
const SENSITIVE_KEYS = new Set([
  'commandcube_session_token',
  'commandcube_device_id',
  'commandcube_server_ip',
  'commandcube_server_port',
  'commandcube_last_paired',
  '@butler_app_sig',              // App signature exchanged during QR pair
  '@sc_known_good_ips_v1',        // Known-good IP:port list (LAN topology data)
  '@sc_auth_disabled_v1',         // Auth-disabled flag — must not be writable in plaintext
  '@butler_scripts_nexus_v1',     // ButlerScript library
  '@botler_auto_saved_research',  // KB findings
  '@butler_conv_nexus_v1',        // Chat history
  '@butler_stable_state',
  'BUTLER_STABLE_STATE',
  'BUTLER_AUTO_UPGRADES',
  '@butler_user_avatar_v1',
  '@butler_ai_avatar_v1',
]);

const ENC_PREFIX       = '__ENC__';
const SALT             = 'butler-ai-local-v1-salt-2025';
const MIGRATION_DONE_KEY = '@butler_enc_migration_v1';

// SecureStore vault keys for the persistent derived key (skips KDF on boot)
const DERIVED_KEY_STORE        = 'butler_derived_key_v1';
const DERIVED_DEVICE_ID_STORE  = 'butler_derived_device_id_v1';

// ── Derive a 32-byte key from device ID ─────────────────────────
let _keyCache: string | null = null;
let _deviceIdForKey: string | null = null;

async function deriveKey(deviceId: string): Promise<string> {
  // 1. In-memory cache — fastest, same JS session.
  if (_keyCache && _deviceIdForKey === deviceId) return _keyCache;

  // 2. Persistent cache via SecureStore — survives app restarts.
  //    1000 SHA-256 iterations cost 300–1000ms on Android. Without
  //    this, that work runs on EVERY cold start inside bootstrap()
  //    and contributes directly to "app feels sluggish on first
  //    open" reports.
  try {
    const ss = getSecureStore();
    if (ss?.getItemAsync) {
      const [cachedKey, cachedId] = await Promise.all([
        ss.getItemAsync(DERIVED_KEY_STORE).catch(() => null),
        ss.getItemAsync(DERIVED_DEVICE_ID_STORE).catch(() => null),
      ]);
      if (cachedKey && cachedId === deviceId) {
        _keyCache = cachedKey;
        _deviceIdForKey = deviceId;
        return cachedKey;
      }
    }
  } catch { /* SecureStore unavailable — fall through to derive */ }

  // 3. First-ever install (or device-id changed): run the full KDF.
  //    Stretch: hash the seed 1000 times (lightweight PBKDF2 approximation)
  let seed = `${deviceId}:${SALT}`;
  for (let i = 0; i < 1000; i++) {
    seed = await getCrypto().digestStringAsync(getCrypto().CryptoDigestAlgorithm.SHA256, seed);
  }
  _keyCache = seed;
  _deviceIdForKey = deviceId;

  // Persist for next launch — fire-and-forget, never blocks.
  try {
    const ss = getSecureStore();
    if (ss?.setItemAsync) {
      ss.setItemAsync(DERIVED_KEY_STORE, seed).catch(() => {});
      ss.setItemAsync(DERIVED_DEVICE_ID_STORE, deviceId).catch(() => {});
    }
  } catch {}

  return seed;
}

// ── XOR-stream cipher using SHA-256 key blocks ──────────────────
function toBytes(hex: string): number[] {
  const bytes: number[] = [];
  for (let i = 0; i < hex.length; i += 2) {
    bytes.push(parseInt(hex.slice(i, i + 2), 16));
  }
  return bytes;
}

function toHex(bytes: number[]): string {
  return bytes.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function streamXOR(keyHex: string, ivHex: string, inputHex: string): Promise<string> {
  const inputBytes = toBytes(inputHex);
  const result: number[] = [];
  let blockSeed = `${keyHex}:${ivHex}`;
  let keyStream: number[] = [];

  for (let i = 0; i < inputBytes.length; i++) {
    if (keyStream.length === 0) {
      // Generate next 32-byte key block
      blockSeed = await getCrypto().digestStringAsync(getCrypto().CryptoDigestAlgorithm.SHA256, blockSeed);
      keyStream = toBytes(blockSeed);
    }
    result.push(inputBytes[i] ^ keyStream.shift()!);
  }
  return toHex(result);
}

// ── Convert string ↔ hex ─────────────────────────────────────────
function strToHex(str: string): string {
  return Array.from(new TextEncoder().encode(str))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

function hexToStr(hex: string): string {
  const bytes = toBytes(hex);
  return new TextDecoder().decode(new Uint8Array(bytes));
}

// ── Base64 ──────────────────────────────────────────────────────
function hexToBase64(hex: string): string {
  const bytes = toBytes(hex);
  let binary = '';
  bytes.forEach(b => { binary += String.fromCharCode(b); });
  return btoa(binary);
}

function base64ToHex(b64: string): string {
  const binary = atob(b64);
  const bytes: number[] = [];
  for (let i = 0; i < binary.length; i++) {
    bytes.push(binary.charCodeAt(i));
  }
  return toHex(bytes);
}

// ── Random IV (16 bytes → 32 hex chars) ─────────────────────────
// Uses expo-crypto.getRandomBytesAsync for CSPRNG entropy.
// Fallback: XOR of four sources (time, Math.random x2, performance.now)
// when expo-crypto is unavailable — still an improvement over a single
// predictable seed, but callers should prefer the primary path.
async function randomIV(): Promise<string> {
  try {
    const c = getCrypto();
    if (c?.getRandomBytesAsync) {
      const bytes: Uint8Array = await c.getRandomBytesAsync(16);
      return Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('');
    }
  } catch {}
  // Fallback: blend 4 independent entropy sources and hash
  const e1 = Date.now().toString(36);
  const e2 = Math.random().toString(36).slice(2);
  const e3 = Math.random().toString(36).slice(2);
  const e4 = (typeof performance !== 'undefined' ? performance.now() : Date.now() ^ 0xABCD).toString(36);
  const seed = `${e1}-${e2}-${e3}-${e4}-butler-iv`;
  const hash = await getCrypto().digestStringAsync(getCrypto().CryptoDigestAlgorithm.SHA256, seed);
  return hash.slice(0, 32);
}

// ── Encrypt a plain-text value ───────────────────────────────────
async function encrypt(plaintext: string, keyHex: string): Promise<string> {
  const iv        = await randomIV();
  const inputHex  = strToHex(plaintext);
  const cipherHex = await streamXOR(keyHex, iv, inputHex);
  // Format: iv(32 hex) + cipherHex → base64
  const combined  = iv + cipherHex;
  return ENC_PREFIX + hexToBase64(combined);
}

// ── Decrypt an encrypted value ───────────────────────────────────
async function decrypt(ciphertext: string, keyHex: string): Promise<string> {
  if (!ciphertext.startsWith(ENC_PREFIX)) return ciphertext; // legacy unencrypted value
  const b64       = ciphertext.slice(ENC_PREFIX.length);
  const combined  = base64ToHex(b64);
  const iv        = combined.slice(0, 32);
  const cipherHex = combined.slice(32);
  const plainHex  = await streamXOR(keyHex, iv, cipherHex);
  return hexToStr(plainHex);
}

// ── Public API ───────────────────────────────────────────────────
class EncryptedStorage {
  private _key: string | null = null;

  /** Call once at app boot with the device ID to prime the key cache */
  async init(deviceId: string): Promise<void> {
    this._key = await deriveKey(deviceId);
  }

  private async _getKey(): Promise<string | null> {
    if (this._key) return this._key;
    // Lazy init: try SecureStore (preferred — device-id is stored there during derive)
    // before falling back to raw AsyncStorage to avoid a chicken-and-egg bootstrap.
    try {
      const ss = getSecureStore();
      if (ss?.getItemAsync) {
        const [cachedKey, cachedId] = await Promise.all([
          ss.getItemAsync(DERIVED_KEY_STORE).catch(() => null),
          ss.getItemAsync(DERIVED_DEVICE_ID_STORE).catch(() => null),
        ]);
        if (cachedKey && cachedId) {
          this._key = cachedKey;
          _keyCache = cachedKey;
          _deviceIdForKey = cachedId;
          return this._key;
        }
      }
    } catch {}
    // SecureStore miss — bootstrap from deviceIdentifier (stable hardware ID)
    try {
      const { deviceIdentifier } = await import('./deviceIdentifier');
      const id = await deviceIdentifier.getDeviceId();
      if (id) {
        this._key = await deriveKey(id);
        return this._key;
      }
    } catch {}
    return null;
  }

  async setItem(key: string, value: string): Promise<void> {
    if (!SENSITIVE_KEYS.has(key)) {
      return AsyncStorage.setItem(key, value);
    }
    try {
      const k = await this._getKey();
      const stored = k ? await encrypt(value, k) : value;
      await AsyncStorage.setItem(key, stored);
    } catch {
      // Fallback to plain storage if encryption fails
      await AsyncStorage.setItem(key, value);
    }
  }

  async getItem(key: string): Promise<string | null> {
    const raw = await AsyncStorage.getItem(key);
    if (!raw || !SENSITIVE_KEYS.has(key)) return raw;
    if (!raw.startsWith(ENC_PREFIX)) return raw; // already plain (migration)
    try {
      const k = await this._getKey();
      return k ? await decrypt(raw, k) : raw;
    } catch {
      return raw;
    }
  }

  async removeItem(key: string): Promise<void> {
    return AsyncStorage.removeItem(key);
  }

  async multiSet(pairs: [string, string][]): Promise<void> {
    const k = await this._getKey();
    const encrypted: [string, string][] = await Promise.all(
      pairs.map(async ([key, value]) => {
        if (SENSITIVE_KEYS.has(key) && k) {
          return [key, await encrypt(value, k)] as [string, string];
        }
        return [key, value] as [string, string];
      })
    );
    await AsyncStorage.multiSet(encrypted);
  }

  async multiGet(keys: string[]): Promise<readonly [string, string | null][]> {
    const raw = await AsyncStorage.multiGet(keys);
    const k = await this._getKey();
    return Promise.all(
      raw.map(async ([key, value]) => {
        if (value && SENSITIVE_KEYS.has(key) && value.startsWith(ENC_PREFIX) && k) {
          try { return [key, await decrypt(value, k)] as [string, string | null]; }
          catch { return [key, value] as [string, string | null]; }
        }
        return [key, value] as [string, string | null];
      })
    );
  }

  /**
   * One-time migration: reads every SENSITIVE_KEY stored as plaintext in raw
   * AsyncStorage and re-writes it encrypted. Runs ONCE per install — guarded
   * by the MIGRATION_DONE_KEY flag so subsequent boots skip it entirely.
   *
   * Call from app boot (nexusIntegrityEngine.runScan) after encryptedStorage
   * is initialised. Safe to call concurrently — second call is a no-op.
   */
  async migrate(): Promise<void> {
    try {
      // Guard: skip if already migrated on this device
      const already = await AsyncStorage.getItem(MIGRATION_DONE_KEY).catch(() => null);
      if (already === '1') return;
    } catch { return; }

    const k = await this._getKey();
    if (!k) return; // encryption key not ready — will retry next boot

    let migrated = 0;
    for (const key of Array.from(SENSITIVE_KEYS)) {
      try {
        const val = await AsyncStorage.getItem(key);
        if (val && !val.startsWith(ENC_PREFIX)) {
          const enc = await encrypt(val, k);
          await AsyncStorage.setItem(key, enc);
          migrated++;
        }
      } catch { /* skip individual key failures — partial migration is still progress */ }
    }

    // Mark migration complete only after all keys are processed
    await AsyncStorage.setItem(MIGRATION_DONE_KEY, '1').catch(() => {});
  }
}

export const encryptedStorage = new EncryptedStorage();

// ── Convenience wrappers matching AsyncStorage API ───────────────
export async function secureSet(key: string, value: string): Promise<void> {
  return encryptedStorage.setItem(key, value);
}
export async function secureGet(key: string): Promise<string | null> {
  return encryptedStorage.getItem(key);
}
