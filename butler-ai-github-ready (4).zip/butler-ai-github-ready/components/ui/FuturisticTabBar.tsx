/**
 * FuturisticTabBar — NEXUS COMMAND DOCK v9.0 BUTLER EDITION
 *
 * ARCHITECTURE:
 *   ButlerLauncherChip is rendered as a NORMAL flex child ABOVE the dock —
 *   NOT position:absolute. The entire component is position:absolute at
 *   the bottom, and inside it we stack: [ButlerLauncherChip] then [Dock].
 *
 * VISUAL:
 *   5 primary tabs visible, no scroll, no cramming: HOME, SCRIPTS,
 *   AI CHAT, TOOLS, CONFIG. Everything else (Knowledge, PC Intel,
 *   Builder, Vault, Pair PC, Skins) lives one tap away behind TOOLS.
 *   Butler-robot themed icons. Multi-color signal line.
 *   Active tab: glowing top stripe + tinted bg + pulsing dot.
 */

import React, { useEffect, useRef, useMemo, useState, useCallback } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, Platform, Animated,
  Dimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import type { BottomTabBarProps } from '@react-navigation/bottom-tabs';
import { haptics } from '@/services/haptics';
import { useCosmetic } from '@/contexts/CosmeticContext';
import ButlerLauncherChip from '@/components/ui/ButlerLauncherChip';
import { getButlerUnreadCount, subscribeButlerUnread, clearButlerUnread } from '@/services/butlerUnread';
import {
  NexusCoreIcon, ForgeScriptsIcon, ButlerAIIcon, KnowledgeBaseIcon,
  IntelLogsIcon, BuilderIcon, VaultIcon, ConfigIcon, SkinsIcon,
} from '@/components/ui/NexusTabIcons';
import Svg, {
  Path, Circle, Rect, Line, G, Polygon, Defs, LinearGradient, Stop,
} from 'react-native-svg';

// Unread state now lives in services/butlerUnread.ts — a standalone module
// both this file and ButlerLauncherChip.tsx read from, avoiding a circular
// import between them. notifyButlerNewMessage/clearButlerUnread are
// re-exported here so existing callers of this file's exports keep working.
export { notifyButlerNewMessage, clearButlerUnread } from '@/services/butlerUnread';

// ── CONSTANTS ────────────────────────────────────────────────────
const MONO: any = Platform.OS === 'ios' ? 'Courier' : 'monospace';
const DOCK_H = 62;   // height of the dock itself
const ICON_S = 21;
const _SW    = Math.max(320, Dimensions.get('window').width);

// Everything except the 5 primary destinations is reached through the
// TOOLS hub (app/(tabs)/tools.tsx) rather than the tab bar itself — this
// keeps the dock to 5 legible, well-spaced tabs instead of 10 cramped ones.
const HIDDEN_TABS = new Set(['onboarding', 'index', 'terminal', 'support']);

const TAB_ALIASES: Record<string, string> = {
  home: 'nexushome', nexushome: 'nexushome', core: 'nexushome',
  scripts: 'scripts', forge: 'scripts',
  butlr: 'butler', butler: 'butler', ai: 'butler', chat: 'butler',
  tools: 'tools', toolbox: 'tools',
  knowledge: 'knowledge', kb: 'knowledge',
  logs: 'logs', pc: 'logs', intel: 'logs',
  builder: 'builder', build: 'builder',
  fileshare: 'fileshare', vault: 'fileshare',
  settings: 'settings', config: 'settings', cfg: 'settings',
  cosmetic: 'cosmetic', themes: 'cosmetic', skins: 'cosmetic',
  connect: 'connect', pair: 'connect',
};

// Labels are just text — no reason for these to change with the skin.
const TAB_LABELS: Record<string, string> = {
  nexushome: 'HOME',    scripts: 'SCRIPTS', butler: 'AI CHAT',
  tools:     'TOOLS',   settings: 'CONFIG',
  // Reachable via the TOOLS hub — kept here only so labels/colors
  // stay correct if ever deep-linked or re-shown.
  knowledge: 'KB',      logs: 'PC',   builder: 'BUILD',
  fileshare: 'NET',     cosmetic: 'SKIN', connect: 'PAIR',
};

// Colors DO need to follow the active skin — this is the exact bug class
// that made the AI chat bar stuck green regardless of skin: colors baked
// into a module-level object instead of read from useCosmetic(). Only 3
// truly distinct hues exist per theme (primary/secondary/tertiary), so a
// couple of tabs intentionally share a hue — that's a design tradeoff,
// not a leftover bug.
function buildTabColors(T: any): Record<string, string> {
  return {
    nexushome: T.primary,
    scripts:   T.secondary,
    butler:    T.tertiary,
    tools:     T.textAccent,
    settings:  T.textMid,
    knowledge: T.primary,
    logs:      T.tertiary,
    builder:   T.secondary,
    fileshare: T.textAccent,
    cosmetic:  T.secondary,
    connect:   T.tertiary,
  };
}

function getLabel(r: string) { return TAB_LABELS[r] ?? r.slice(0, 4).toUpperCase(); }

// ── BUTLER-ROBOT-THEMED ICONS — all custom SVG ────────────────────
// Each tab has a unique robot/butler design element

// PAIR / CONNECT — QR Scanner robot eye
function PairIcon({ size = 17, color = '#00CCBB', active = false }) {
  const s = size, cx = s / 2, cy = s / 2;
  return (
    <Svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
      {/* Outer QR frame corners */}
      <Rect x={cx - s*0.42} y={cy - s*0.42} width={s*0.26} height={s*0.26} rx={s*0.04}
        stroke={color} strokeWidth={s*0.06} fill="none" />
      <Rect x={cx + s*0.16} y={cy - s*0.42} width={s*0.26} height={s*0.26} rx={s*0.04}
        stroke={color} strokeWidth={s*0.06} fill="none" />
      <Rect x={cx - s*0.42} y={cy + s*0.16} width={s*0.26} height={s*0.26} rx={s*0.04}
        stroke={color} strokeWidth={s*0.06} fill="none" />
      {/* Inner squares */}
      <Rect x={cx - s*0.30} y={cy - s*0.30} width={s*0.12} height={s*0.12} rx={s*0.02} fill={color} opacity={0.8} />
      <Rect x={cx + s*0.18} y={cy - s*0.30} width={s*0.12} height={s*0.12} rx={s*0.02} fill={color} opacity={0.8} />
      <Rect x={cx - s*0.30} y={cy + s*0.18} width={s*0.12} height={s*0.12} rx={s*0.02} fill={color} opacity={0.8} />
      {/* Bottom right: robot eye instead of QR */}
      <Circle cx={cx + s*0.28} cy={cy + s*0.28} r={s*0.16} stroke={color} strokeWidth={s*0.05} fill="none" />
      <Circle cx={cx + s*0.28} cy={cy + s*0.28} r={s*0.06} fill={color} opacity={active ? 1 : 0.6} />
      {/* Scan line */}
      {active && <Line x1={cx - s*0.46} y1={cy - s*0.02} x2={cx + s*0.46} y2={cy - s*0.02}
        stroke={color} strokeWidth={s*0.03} opacity={0.5} />}
    </Svg>
  );
}

// TOOLS — robot wrench-and-gear glyph
function ToolsIcon({ size = 17, color = '#FFB020', active = false }) {
  const s = size, cx = s / 2, cy = s / 2;
  return (
    <Svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
      {/* Outer gear ring */}
      <Circle cx={cx} cy={cy} r={s * 0.36} stroke={color} strokeWidth={s * 0.07} fill="none" opacity={0.9} />
      {/* Gear teeth */}
      {[0, 45, 90, 135, 180, 225, 270, 315].map(deg => {
        const rad = (deg * Math.PI) / 180;
        const r1 = s * 0.36, r2 = s * 0.47;
        return (
          <Line key={deg}
            x1={cx + r1 * Math.cos(rad)} y1={cy + r1 * Math.sin(rad)}
            x2={cx + r2 * Math.cos(rad)} y2={cy + r2 * Math.sin(rad)}
            stroke={color} strokeWidth={s * 0.08} strokeLinecap="round" opacity={active ? 1 : 0.75} />
        );
      })}
      {/* Center bolt — robot eye */}
      <Circle cx={cx} cy={cy} r={s * 0.12} fill={color} opacity={active ? 1 : 0.7} />
    </Svg>
  );
}

function renderIcon(routeName: string, color: string, active: boolean) {
  const props = { size: ICON_S, color, active, dimOpacity: 0.88 };
  switch (routeName) {
    case 'nexushome':  return <NexusCoreIcon    {...props} />;
    case 'scripts':    return <ForgeScriptsIcon {...props} />;
    case 'butler':     return <ButlerAIIcon     {...props} />;
    case 'tools':      return <ToolsIcon size={ICON_S} color={color} active={active} />;
    case 'knowledge':  return <KnowledgeBaseIcon {...props} />;
    case 'logs':       return <IntelLogsIcon    {...props} />;
    case 'builder':    return <BuilderIcon      {...props} />;
    case 'fileshare':  return <VaultIcon        {...props} />;
    case 'settings':   return <ConfigIcon       {...props} />;
    case 'cosmetic':   return <SkinsIcon        {...props} />;
    case 'connect':    return <PairIcon size={ICON_S} color={color} active={active} />;
    default:           return <ButlerAIIcon     {...props} />;
  }
}

// ── TAB PILL ─────────────────────────────────────────────────────
interface TabPillProps {
  routeName: string;
  isFocused: boolean;
  label: string;
  color: string;
  flex: number;
  onPress: () => void;
}

const TabPill = React.memo(function TabPill({ routeName, isFocused, label, color, flex, onPress }: TabPillProps) {
  const shortLabel = getLabel(routeName);

  const scaleA  = useRef(new Animated.Value(isFocused ? 1.05 : 1)).current;
  const opA     = useRef(new Animated.Value(isFocused ? 1 : 0.52)).current;
  const dotA    = useRef(new Animated.Value(0.4)).current;
  const redDotA = useRef(new Animated.Value(0.5)).current;
  const [hasUnread, setHasUnread] = useState(getButlerUnreadCount() > 0 && routeName === 'butler');

  useEffect(() => {
    if (routeName !== 'butler') return;
    return subscribeButlerUnread(count => setHasUnread(count > 0));
  }, [routeName]);

  useEffect(() => {
    if (isFocused && routeName === 'butler') clearButlerUnread();
  }, [isFocused, routeName]);

  useEffect(() => {
    Animated.parallel([
      Animated.spring(scaleA, { toValue: isFocused ? 1.05 : 1, useNativeDriver: true, speed: 35, bounciness: 12 }),
      Animated.timing(opA,    { toValue: isFocused ? 1 : 0.52,  useNativeDriver: true, duration: 170 }),
    ]).start();
  }, [isFocused]);

  useEffect(() => {
    if (!isFocused) return;
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(dotA, { toValue: 1,   duration: 900, useNativeDriver: true }),
      Animated.timing(dotA, { toValue: 0.1, duration: 900, useNativeDriver: true }),
    ]));
    loop.start(); return () => loop.stop();
  }, [isFocused]);

  useEffect(() => {
    if (!hasUnread) return;
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(redDotA, { toValue: 1,   duration: 380, useNativeDriver: true }),
      Animated.timing(redDotA, { toValue: 0.2, duration: 380, useNativeDriver: true }),
    ]));
    loop.start(); return () => loop.stop();
  }, [hasUnread]);

  return (
    <TouchableOpacity
      onPress={() => { haptics.light(); onPress(); }}
      activeOpacity={0.8}
      style={{ flex, alignItems: 'center', justifyContent: 'center' }}
      accessibilityRole="button"
      accessibilityState={{ selected: isFocused }}
      accessibilityLabel={label}
    >
      <Animated.View style={[
        tp.inner,
        isFocused
          ? { backgroundColor: color + '1A', borderColor: color + '65' }
          : { backgroundColor: 'transparent', borderColor: 'transparent' },
        { transform: [{ scale: scaleA }], opacity: opA },
      ]}>
        {/* Glowing top stripe */}
        {isFocused && (
          <View style={[tp.stripe, {
            backgroundColor: color,
            shadowColor: color,
            shadowOpacity: 0.9, shadowRadius: 7,
            shadowOffset: { width: 0, height: 0 },
          }]} />
        )}

        {/* Icon */}
        <View style={tp.iconWrap}>
          {renderIcon(routeName, color, isFocused)}
          {isFocused && (
            <Animated.View style={[tp.activeDot, { backgroundColor: color, opacity: dotA }]} />
          )}
          {hasUnread && !isFocused && (
            <Animated.View style={[tp.unreadDot, { opacity: redDotA }]} />
          )}
        </View>

        {/* Short label */}
        <Text style={[tp.label, { color: isFocused ? color : color + '60' }]} numberOfLines={1}>
          {shortLabel}
        </Text>
      </Animated.View>
    </TouchableOpacity>
  );
});

const tp = StyleSheet.create({
  inner: {
    alignItems: 'center', justifyContent: 'center',
    paddingTop: 7, paddingBottom: 5, paddingHorizontal: 2,
    borderRadius: 11, borderWidth: 1.5,
    minWidth: 40, width: '92%',
    position: 'relative', overflow: 'hidden',
  },
  stripe: {
    position: 'absolute', top: 0, left: 3, right: 3,
    height: 2.5, borderRadius: 1.5,
  },
  iconWrap: {
    position: 'relative', alignItems: 'center', justifyContent: 'center',
    marginBottom: 2,
  },
  activeDot: {
    position: 'absolute', bottom: -4, width: 3.5, height: 3.5, borderRadius: 1.75,
  },
  unreadDot: {
    position: 'absolute', top: -3, right: -5,
    width: 8, height: 8, borderRadius: 4,
    backgroundColor: '#FF3344', borderWidth: 1.5, borderColor: '#010508',
  },
  label: {
    fontFamily: MONO, fontSize: 8.5, fontWeight: '900', letterSpacing: 0.3,
    textAlign: 'center', includeFontPadding: false,
  },
});

// ── MAIN TAB BAR ─────────────────────────────────────────────────
export default function FuturisticTabBar(
  props: BottomTabBarProps & {
    iconMap?: Record<string, (color: string, size: number) => React.ReactNode>;
  },
) {
  const { state, descriptors, navigation } = props;
  const insets = useSafeAreaInsets();
  const { T } = useCosmetic();
  const tabColors = useMemo(() => buildTabColors(T), [T]);

  // Wire global tab switch
  useEffect(() => {
    (global as any).__butlerSwitchTab = (tab: string) => {
      const route = TAB_ALIASES[String(tab || '').toLowerCase()] || tab;
      try { navigation.navigate(route as never); } catch {}
    };
    return () => { delete (global as any).__butlerSwitchTab; };
  }, [navigation]);

  const visibleRoutes = useMemo(() =>
    state.routes
      .map((route, idx) => ({ route, idx }))
      .filter(({ route }) => {
        if (HIDDEN_TABS.has(route.name)) return false;
        const opts = descriptors[route.key].options as any;
        if (opts?.href === null)                                        return false;
        if (opts?.tabBarButton === null)                                return false;
        if ((opts?.tabBarItemStyle as any)?.display === 'none')        return false;
        return true;
      }),
    [state.routes, descriptors],
  );

  const activeRouteName = visibleRoutes.find(r => r.idx === state.index)?.route?.name ?? 'nexushome';
  const isOnButlerTab   = activeRouteName === 'butler';

  // Bottom safe area padding
  const bottomPad = Math.max(insets.bottom, Platform.OS === 'android' ? 6 : 0);

  // Multi-color signal stripe from visible tabs
  const signalColors = visibleRoutes.map(({ route }) => tabColors[route.name] ?? T.primary);

  return (
    /**
     * ROOT LAYOUT:
     *   position:absolute covers the bottom area.
     *   Inner is a COLUMN:  [ButlerLauncherChip] → [Dock]
     *   This is the key fix — the bar is a SIBLING not an absolute overlay.
     */
    <View
      pointerEvents="box-none"
      style={[st.root, { paddingBottom: bottomPad }]}
    >
      {/* ── QUICK BUTLER BAR — renders ABOVE the dock ── */}
      {!isOnButlerTab ? (
        <View style={st.barWrapper} pointerEvents="box-none">
          <ButlerLauncherChip />
        </View>
      ) : null}

      {/* ── DROP SHADOW PLATE ── */}
      <View pointerEvents="none" style={st.shadowPlate} />

      {/* ── DOCK ── */}
      <View style={[st.dock, { backgroundColor: T.panel, borderColor: T.borderColor }]}>

        {/* Rainbow signal line across top of dock */}
        <View pointerEvents="none" style={st.signalLine}>
          {signalColors.map((c, i) => (
            <View key={i} style={{ flex: 1, backgroundColor: c }} />
          ))}
        </View>

        {/* Tab row */}
        <View style={st.tabRow}>
          {visibleRoutes.map(({ route, idx }) => {
            const { options } = descriptors[route.key];
            const isFocused   = state.index === idx;
            const label       = typeof options.tabBarLabel === 'string'
              ? options.tabBarLabel : options.title ?? route.name;
            const onPress = () => {
              const ev = navigation.emit({ type: 'tabPress', target: route.key, canPreventDefault: true });
              if (!isFocused && !ev.defaultPrevented) navigation.navigate(route.name as never);
            };
            return (
              <TabPill
                key={route.key}
                routeName={route.name}
                isFocused={isFocused}
                label={String(label)}
                color={tabColors[route.name] ?? T.primary}
                flex={1}
                onPress={onPress}
              />
            );
          })}
        </View>
      </View>
    </View>
  );
}

const st = StyleSheet.create({
  // The absolute root — covers only what it needs
  root: {
    position: 'absolute',
    left: 0, right: 0, bottom: 0,
    flexDirection: 'column',   // ← key: stack vertically
    justifyContent: 'flex-end',
    backgroundColor: 'transparent',
  },

  // Wrapper for ButlerLauncherChip — sits above the dock naturally
  barWrapper: {
    width: '100%',
    // Small gap between bar and dock
    marginBottom: 3,
  },

  shadowPlate: {
    position: 'absolute',
    left: 4, right: 4,
    // Covers just the dock height
    bottom: 0, height: 70,
    borderRadius: 16,
    backgroundColor: '#000',
    opacity: 0.78,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: -6 },
        shadowOpacity: 0.85,
        shadowRadius: 18,
      },
      android: { elevation: 20 },
      default: {},
    }),
  },

  dock: {
    height: DOCK_H,
    marginHorizontal: 4,
    borderRadius: 13,
    overflow: 'hidden',
    borderWidth: 1.5,
    ...Platform.select({ android: { elevation: 14 }, default: {} }),
  },

  signalLine: {
    height: 2.5,
    flexDirection: 'row',
    position: 'absolute',
    top: 0, left: 0, right: 0,
    zIndex: 3,
  },

  tabRow: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    paddingHorizontal: 3,
    paddingTop: 3,   // below signal line
    paddingBottom: 2,
    marginTop: 2.5,
  },
});
