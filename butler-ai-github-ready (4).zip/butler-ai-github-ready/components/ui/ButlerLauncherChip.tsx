/**
 * ButlerLauncherChip — floating "open AI chat" pill.
 *
 * Visual reference: robot avatar in a ringed circle, red unread-count
 * badge, "N NEW · BUTLER ✨" label, pill container with a soft border that
 * turns into a warm glowing ring while there's something unread — same
 * idea as an unread-mail highlight, just applied to the AI chat launcher.
 *
 * This replaces QuickButlerBar in the tab bar's floating slot. It is
 * intentionally simpler than QuickButlerBar (no inline command input,
 * no ghost-text autocomplete) — it's a launcher/notification, not a
 * composer. QuickButlerBar.tsx is untouched and still available if that
 * inline-typing behavior is wanted back later.
 */

import React, { useEffect, useRef, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Animated, Platform } from 'react-native';
import { MaterialCommunityIcons, MaterialIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { Image } from 'expo-image';
import { haptics } from '@/services/haptics';
import { useCosmetic } from '@/contexts/CosmeticContext';
import { hex, glow } from '@/constants/tokens';
import { getButlerUnreadCount, subscribeButlerUnread, clearButlerUnread } from '@/services/butlerUnread';

// Fixed "something's new" color — deliberately NOT theme-derived, same
// reasoning as the app's other fixed semantic colors (connected=green,
// error=red): an attention state should stay recognizable regardless of
// which skin is active, including skins whose primary color IS amber/gold.
const ATTENTION = '#FFC845';

let MASCOT: any = null;
try { MASCOT = require('@/assets/images/nexus-robot-mascot.png'); } catch {
  try { MASCOT = require('@/assets/images/butler-robot-3d.png'); } catch {
    try { MASCOT = require('@/assets/images/mascot_shield_v2.png'); } catch {}
  }
}

export default function ButlerLauncherChip() {
  const router = useRouter();
  const { T } = useCosmetic();
  const [unread, setUnread] = useState(getButlerUnreadCount());
  const glowA  = useRef(new Animated.Value(0)).current;
  const pulseA = useRef(new Animated.Value(1)).current;

  useEffect(() => subscribeButlerUnread(setUnread), []);

  useEffect(() => {
    if (unread > 0) {
      const loop = Animated.loop(Animated.sequence([
        Animated.timing(glowA, { toValue: 1, duration: 900, useNativeDriver: false }),
        Animated.timing(glowA, { toValue: 0.35, duration: 900, useNativeDriver: false }),
      ]));
      loop.start();
      return () => loop.stop();
    }
    glowA.setValue(0);
  }, [unread]);

  useEffect(() => {
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(pulseA, { toValue: 1.06, duration: 1400, useNativeDriver: true }),
      Animated.timing(pulseA, { toValue: 1,    duration: 1400, useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, []);

  const hasUnread  = unread > 0;
  const borderCol  = glowA.interpolate({ inputRange: [0, 1], outputRange: [T.borderColor, ATTENTION] });
  const borderW    = hasUnread ? 1.75 : 1.25;

  const handlePress = () => {
    haptics.light();
    clearButlerUnread();
    try { router.push('/(tabs)/butler' as any); } catch {}
  };

  return (
    <TouchableOpacity activeOpacity={0.85} onPress={handlePress} style={st.touchable}>
      <Animated.View style={[st.pill, {
        backgroundColor: hex(T.panel, 'F0'),
        borderColor: borderCol as any,
        borderWidth: borderW,
        ...Platform.select({
          ios:     { shadowColor: hasUnread ? ATTENTION : T.glowColor, shadowOpacity: hasUnread ? 0.55 : 0.18, shadowRadius: hasUnread ? 12 : 6, shadowOffset: { width: 0, height: 2 } },
          android: { elevation: hasUnread ? 6 : 2 },
          default: {},
        }),
      }]}>
        {/* Avatar */}
        <Animated.View style={[st.avatarRing, { borderColor: hex(T.primary, '80'), transform: [{ scale: pulseA }] }]}>
          {MASCOT
            ? <Image source={MASCOT} style={st.avatarImg} contentFit="cover" />
            : <MaterialCommunityIcons name="robot-happy" size={20} color={T.primary} />}
          <View style={[st.onlineDot, { backgroundColor: '#06D6A0', borderColor: hex(T.panel, 'F0') }]} />
        </Animated.View>

        {hasUnread && (
          <View style={[st.badge, { backgroundColor: '#FF3344', borderColor: hex(T.panel, 'F0') }]}>
            <Text style={st.badgeTxt}>{unread > 9 ? '9+' : unread}</Text>
          </View>
        )}

        {/* Label */}
        <View style={st.labelWrap}>
          <Text style={[st.label, { color: T.textHi }]} numberOfLines={1}>
            {hasUnread ? `${unread} NEW` : 'ASK'} <Text style={{ color: T.textMid ?? T.textDim }}>·</Text> BUTLER
          </Text>
          <MaterialCommunityIcons name="creation" size={12} color={hasUnread ? ATTENTION : T.secondary} style={{ marginLeft: 4 }} />
        </View>

        <MaterialIcons name="chevron-right" size={16} color={T.textMid ?? T.textDim} />
      </Animated.View>
    </TouchableOpacity>
  );
}

const st = StyleSheet.create({
  touchable: { alignSelf: 'center' },
  pill: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    borderRadius: 30, paddingVertical: 6, paddingRight: 12, paddingLeft: 6,
    minWidth: 200,
  },
  avatarRing: {
    width: 34, height: 34, borderRadius: 17, borderWidth: 1.5,
    alignItems: 'center', justifyContent: 'center', overflow: 'visible',
  },
  avatarImg: { width: '100%', height: '100%', borderRadius: 15 },
  onlineDot: {
    position: 'absolute', bottom: -1, right: -1,
    width: 10, height: 10, borderRadius: 5, borderWidth: 2,
  },
  badge: {
    position: 'absolute', left: 22, top: 1,
    minWidth: 17, height: 17, borderRadius: 8.5, paddingHorizontal: 3,
    alignItems: 'center', justifyContent: 'center', borderWidth: 1.5, zIndex: 2,
  },
  badgeTxt: { color: '#FFF', fontSize: 9, fontWeight: '900' },
  labelWrap: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  label: { fontSize: 12.5, fontWeight: '800', letterSpacing: 0.3 },
});
