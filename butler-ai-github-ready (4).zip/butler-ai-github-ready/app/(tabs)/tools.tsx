/**
 * BUTLER AI — TOOLS HUB v1.1
 * Single entry point for every secondary feature: Knowledge Base, PC Intel,
 * Builder, Vault, Pair PC, and Skins. Keeps the bottom tab bar to 5 clean,
 * readable destinations (matching the app's intended nav) instead of
 * cramming 10 tabs into one row. Nothing is removed — every screen below
 * is still the exact same page, just reached through this hub.
 * Colors come from useCosmetic().T so this screen follows the active skin,
 * same as everywhere else — v1.0 used the static tokens.ts palette instead,
 * which was the same "won't respond to a skin change" bug fixed elsewhere.
 */

import React from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, Platform } from 'react-native';
import { router } from 'expo-router';
import { MaterialIcons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { haptics } from '@/services/haptics';
import { useConnectionStatus } from '@/hooks/useConnection';
import { TabErrorBoundary } from '@/components/ui/TabErrorBoundary';
import { useCosmetic } from '@/contexts/CosmeticContext';
import { SPACE, RADIUS, TYPE, glow, hex } from '@/constants/tokens';

// Fixed semantic colors — same choice made everywhere else in the app:
// connected/success and error/offline stay recognizable regardless of skin.
const STATUS_OK  = '#06D6A0';
const STATUS_BAD = '#EF233C';

type IconLib = 'material' | 'community';

interface ToolCard {
  route: string;
  icon: string;
  lib: IconLib;
  color: string;
  title: string;
  desc: string;
}

function buildTools(T: any): ToolCard[] {
  return [
    { route: '/(tabs)/knowledge', icon: 'brain',         lib: 'community', color: T.primary,    title: 'Knowledge Base', desc: 'Everything Butler has learned about your PC' },
    { route: '/(tabs)/logs',      icon: 'bar-chart',      lib: 'material',   color: T.tertiary,   title: 'PC Intel',       desc: 'Live CPU, RAM, disk, and process stats' },
    { route: '/(tabs)/builder',   icon: 'handyman',       lib: 'material',   color: T.secondary,  title: 'Builder',        desc: 'Drag-and-drop automation pipelines' },
    { route: '/(tabs)/fileshare', icon: 'folder-open',    lib: 'material',   color: T.textAccent, title: 'Vault',          desc: 'LAN scanner, port audit, file bridge' },
    { route: '/(tabs)/connect',   icon: 'server-network', lib: 'community', color: T.primary,    title: 'Pair PC',        desc: 'Connect or reconnect the Butler server' },
    { route: '/(tabs)/cosmetic',  icon: 'palette-swatch', lib: 'community', color: T.secondary,  title: 'Skins',          desc: 'Themes, FX, and app appearance' },
  ];
}

function ToolIcon({ card, size = 22 }: { card: ToolCard; size?: number }) {
  const Comp: any = card.lib === 'community' ? MaterialCommunityIcons : MaterialIcons;
  return <Comp name={card.icon as any} size={size} color={card.color} />;
}

function ToolTile({ card, T }: { card: ToolCard; T: any }) {
  return (
    <Pressable
      onPress={() => { haptics.light(); router.push(card.route as any); }}
      style={({ pressed }) => [
        st.tile,
        { borderColor: pressed ? hex(card.color, 'AA') : hex(card.color, '30'),
          backgroundColor: pressed ? glow(card.color, 14) : glow(card.color, 6) },
      ]}
    >
      <View style={[st.tileIconBox, { borderColor: hex(card.color, '45'), backgroundColor: glow(card.color, 10) }]}>
        <ToolIcon card={card} />
      </View>
      <Text style={[TYPE.subtitle, { color: T.textHi }]} numberOfLines={1}>{card.title}</Text>
      <Text style={[TYPE.body, { color: T.textMid ?? T.textDim, fontSize: 9.5 }]} numberOfLines={2}>{card.desc}</Text>
      <View style={st.tileFooter}>
        <View style={[st.tileDot, { backgroundColor: card.color }]} />
        <MaterialIcons name="arrow-forward" size={13} color={hex(card.color, '90')} />
      </View>
    </Pressable>
  );
}

function ToolsInner() {
  const insets = useSafeAreaInsets();
  const { isConnected } = useConnectionStatus();
  const { T } = useCosmetic();
  const TOOLS = React.useMemo(() => buildTools(T), [T]);
  const stripe5 = [T.primary, T.secondary, T.tertiary, T.primary, T.secondary];

  return (
    <View style={{ flex: 1, backgroundColor: T.bg }}>
      {/* ── HEADER ── */}
      <View style={[st.header, { backgroundColor: T.panel, paddingTop: insets.top + SPACE.sm }]}>
        <View style={{ height: 3, flexDirection: 'row' }}>
          {stripe5.map((c, i) => <View key={i} style={{ flex: 1, backgroundColor: c }} />)}
        </View>
        <View style={{ paddingHorizontal: SPACE.lg, paddingTop: SPACE.md, paddingBottom: SPACE.md }}>
          <Text style={[TYPE.caption, { color: hex(T.primary, '70'), letterSpacing: 2 }]}>NEXUS · TOOLBOX</Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 2 }}>
            <Text style={[TYPE.hero, { color: T.textHi }]}>TOOLS</Text>
            <View style={[st.statusPill, { borderColor: hex(isConnected ? STATUS_OK : STATUS_BAD, '55'), backgroundColor: glow(isConnected ? STATUS_OK : STATUS_BAD, 10) }]}>
              <View style={[st.statusDot, { backgroundColor: isConnected ? STATUS_OK : STATUS_BAD }]} />
              <Text style={[TYPE.caption, { color: isConnected ? STATUS_OK : STATUS_BAD }]}>
                {isConnected ? 'PC LIVE' : 'OFFLINE'}
              </Text>
            </View>
          </View>
          <Text style={[TYPE.body, { color: T.textMid ?? T.textDim, marginTop: 4 }]}>Everything else, all in one place.</Text>
        </View>
      </View>

      {/* ── GRID ── */}
      <ScrollView
        contentContainerStyle={{ padding: SPACE.lg, paddingTop: SPACE.md, paddingBottom: 160, flexDirection: 'row', flexWrap: 'wrap', gap: SPACE.md }}
        showsVerticalScrollIndicator={false}
      >
        {TOOLS.map(card => <ToolTile key={card.route} card={card} T={T} />)}
      </ScrollView>
    </View>
  );
}

const st = StyleSheet.create({
  header: { overflow: 'hidden' },
  statusPill: { flexDirection: 'row', alignItems: 'center', gap: 5, borderWidth: 1, borderRadius: 20, paddingHorizontal: 9, paddingVertical: 4 },
  statusDot:  { width: 5, height: 5, borderRadius: 2.5 },
  tile: {
    width: '47.5%',
    borderWidth: 1.5,
    borderRadius: RADIUS.lg,
    padding: SPACE.md,
    gap: 6,
    minHeight: 118,
    ...Platform.select({ ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.25, shadowRadius: 10 }, android: { elevation: 3 }, default: {} }),
  },
  tileIconBox: { width: 36, height: 36, borderRadius: RADIUS.md, borderWidth: 1, alignItems: 'center', justifyContent: 'center', marginBottom: 2 },
  tileFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 'auto', paddingTop: 4 },
  tileDot: { width: 4, height: 4, borderRadius: 2 },
});

export default function ToolsScreen() {
  return (
    <TabErrorBoundary name="Tools">
      <ToolsInner />
    </TabErrorBoundary>
  );
}
