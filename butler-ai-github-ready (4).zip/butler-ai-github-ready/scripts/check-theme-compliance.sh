#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────
# check-theme-compliance.sh
#
# Catches the exact bug class that made the AI Chat bar (and 9 other
# spots in butler.tsx) stuck on hardcoded colors that Settings -> Skins
# could never change: raw hex color literals living outside the theme
# system instead of coming from useCosmetic().T.
#
# Run this before shipping any UI change:
#   bash scripts/check-theme-compliance.sh
#
# Exit code 0 = clean. Exit code 1 = hardcoded colors found (prints
# every file + line so you can fix or consciously allow-list them).
# ─────────────────────────────────────────────────────────────────
set -uo pipefail
cd "$(dirname "$0")/.."

# Files allowed to contain raw hex — the theme system itself, and the
# design-tokens file used by the non-cosmetic (older) token system.
ALLOWLIST_REGEX='contexts/CosmeticContext\.tsx|constants/tokens\.ts|scripts/check-theme-compliance\.sh'

HITS=0
while IFS= read -r -d '' file; do
  if echo "$file" | grep -qE "$ALLOWLIST_REGEX"; then
    continue
  fi
  matches=$(grep -noE "#[0-9A-Fa-f]{6}\b|#[0-9A-Fa-f]{3}\b" "$file" || true)
  if [ -n "$matches" ]; then
    count=$(echo "$matches" | wc -l)
    echo "── $file  ($count hardcoded hex)"
    echo "$matches" | sed 's/^/     /' | head -5
    if [ "$count" -gt 5 ]; then echo "     ... and $((count - 5)) more"; fi
    HITS=$((HITS + count))
  fi
done < <(find app components -type f \( -name "*.tsx" -o -name "*.ts" \) -print0)

echo
if [ "$HITS" -eq 0 ]; then
  echo "✅ Clean — no hardcoded colors found outside the theme system."
  exit 0
else
  echo "❌ $HITS hardcoded color literal(s) found outside the theme system."
  echo "   These will NOT respond to skin changes in Settings -> Skins."
  echo "   Fix: pull colors from useCosmetic().T instead (see QuickButlerBar.tsx"
  echo "   or app/(tabs)/butler.tsx's useButlerPalette() for the pattern)."
  echo "   If a color is intentionally fixed (e.g. universal error red), add its"
  echo "   file to ALLOWLIST_REGEX in this script with a comment explaining why."
  exit 1
fi
