#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────
# check-theme-compliance-v2.sh
#
# Superset of check-theme-compliance.sh. The v1 script only matches
# 6/3-digit hex literals with a regex word boundary, so it silently
# misses three whole bug classes that are just as real:
#
#   (A) rgba()/rgb()/hsl()/hsla() color literals
#   (B) 8-digit hex with an alpha channel (#RRGGBBAA) — the trailing
#       hex digits after position 6 are still "word" characters, so
#       \b never fires and v1 skips these entirely
#   (C) files that import the STATIC `COLOR` palette object from
#       constants/tokens.ts and use COLOR.xxx directly — this is
#       invisible to any hex-literal regex because the literal hex
#       lives safely inside the allow-listed tokens.ts file, not in
#       the consuming file. This is the exact bug class the audit
#       found by hand in tools.tsx ("built using the static palette
#       instead of the live theme") — v1 cannot find more instances
#       of it because it never looks for imports, only hex text.
#
# Run: bash scripts/check-theme-compliance-v2.sh
# Exit 0 = clean, exit 1 = issues found.
# ─────────────────────────────────────────────────────────────────
set -uo pipefail
cd "$(dirname "$0")/.."

ALLOWLIST_REGEX='contexts/CosmeticContext\.tsx|constants/tokens\.ts|scripts/check-theme-compliance'

TOTAL=0

echo "════════════════════════════════════════════════════════════════"
echo "(A) + (B): rgba()/rgb()/hsl()/hsla() and 8-digit hex literals"
echo "════════════════════════════════════════════════════════════════"
A_HITS=0
while IFS= read -r -d '' file; do
  echo "$file" | grep -qE "$ALLOWLIST_REGEX" && continue
  matches=$(grep -noE "rgba?\([0-9][^)]*\)|hsla?\([^)]*\)|#[0-9A-Fa-f]{8}\b" "$file" || true)
  if [ -n "$matches" ]; then
    count=$(echo "$matches" | wc -l)
    echo "── $file  ($count)"
    echo "$matches" | sed 's/^/     /' | head -5
    [ "$count" -gt 5 ] && echo "     ... and $((count - 5)) more"
    A_HITS=$((A_HITS + count))
  fi
done < <(find app components -type f \( -name "*.tsx" -o -name "*.ts" \) -print0)
echo "Subtotal: $A_HITS"
TOTAL=$((TOTAL + A_HITS))

echo
echo "════════════════════════════════════════════════════════════════"
echo "(C) Static tokens.ts COLOR palette used instead of live useCosmetic().T"
echo "════════════════════════════════════════════════════════════════"
C_HITS=0
while IFS= read -r -d '' file; do
  echo "$file" | grep -qE "$ALLOWLIST_REGEX" && continue
  if grep -qE "from ['\"].*constants/tokens['\"]" "$file" 2>/dev/null; then
    count=$(grep -oE "\bCOLOR\.[A-Za-z0-9_]+" "$file" | wc -l)
    if [ "$count" -gt 0 ]; then
      echo "── $file  ($count usages of static COLOR.*)"
      C_HITS=$((C_HITS + count))
    fi
  fi
done < <(find app components -type f \( -name "*.tsx" -o -name "*.ts" \) -print0)
echo "Subtotal: $C_HITS"
TOTAL=$((TOTAL + C_HITS))

echo
echo "════════════════════════════════════════════════════════════════"
if [ "$TOTAL" -eq 0 ]; then
  echo "✅ Clean — no rgba/hsl/8-digit-hex/static-palette issues found."
  exit 0
else
  echo "❌ $TOTAL additional issue(s) found — none of these are caught by"
  echo "   check-theme-compliance.sh (v1), which only regexes 6/3-digit hex."
  echo "   Run v1 alongside this script for the full picture. A file can"
  echo "   show 0 in v1 and still be full of dead-theme colors, as with"
  echo "   several files previously marked 'done'."
  exit 1
fi
