# PERMANENT ERROR REMOVAL — 30 seconds

Put `nexus-autofix.js` in your project root (or a `tools/` folder), then:

```bash
# 1. See what will crash at startup
node nexus-autofix.js

# 2. Permanently delete every one of them
node nexus-autofix.js --strip --backup

# 3. Confirm clean
node nexus-autofix.js
```

`--backup` writes a `.bak` next to any file it edits. Drop it if you don't want them.

## What it does

Finds every JSX component that is **used but never imported or defined** — the
exact class of bug that threw `PerformanceStrip is not defined` and crashed your
CORE tab. Then `--strip` removes them from the JSX tree permanently:

- `<Foo />` → deleted
- `<Foo></Foo>` → deleted
- `<Foo>children</Foo>` → wrapper deleted, **children kept**

## Verified on your codebase

| Run | Result |
|---|---|
| Scan of 106 files (app/ + components/) | **0 crash risks — startup clean** |
| Injected `<PerformanceStrip/>` into `nexushome.tsx` | **Caught it** — `nexushome.tsx:1926` |
| `--strip` | Removed it, re-scan clean |
| `diff` against original 1,929-line file | **1 blank line.** Nothing else touched. |

It does **not** flag TypeScript generics (`useState<SyncStatus>`, `Record<Tab,X>`,
`<K extends keyof T>`), JSDoc examples, string literals, lazy `React.lazy()`
components, or `const [WebView, setWebView] = useState()` state components.
Those were all false positives in the first pass and are now explicitly excluded —
which is why it is safe to run `--strip`.

## Exit codes

`0` = clean (or strip completed) · `1` = crash risks found. Safe to wire into CI
or a prebuild hook:

```json
"scripts": { "prestart": "node tools/nexus-autofix.js" }
```
