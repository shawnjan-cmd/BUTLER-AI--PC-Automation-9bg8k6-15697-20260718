#!/usr/bin/env node
/**
 * nexus-deepscan.js — IMPORT GRAPH AUDIT
 * ------------------------------------------------------------------
 * nexus-autofix.js catches components used but never imported.
 * This catches the THREE crash classes it cannot see:
 *
 *   [A] BROKEN PATH     import X from './does-not-exist'
 *                       -> "Unable to resolve module" — HARD boot crash,
 *                          the whole app dies, not just one tab.
 *
 *   [B] MISSING EXPORT  import { Foo } from './bar'   (bar has no Foo)
 *                       -> Foo is undefined -> "Element type is invalid:
 *                          expected a string or a class/function but got:
 *                          undefined". THIS IS THE EXACT BUG CLASS THAT
 *                          KILLED PerformanceStrip.
 *
 *   [C] UNWIRED         A component file that nothing ever imports.
 *                       NOT a crash. NOT deleted. Reported so you can
 *                       wire up the things you built and forgot.
 *
 * Usage:
 *   node tools/nexus-deepscan.js
 *   node tools/nexus-deepscan.js --root=/path/to/project
 *
 * READ-ONLY. This tool never edits or deletes anything, ever.
 */

const fs = require('fs');
const path = require('path');

const ROOT = process.argv.find(a => a.startsWith('--root='))?.split('=')[1] || process.cwd();
const SCAN_DIRS = ['app', 'components', 'screens', 'src', 'services', 'contexts', 'constants', 'hooks'];
const CODE_EXT = ['.tsx', '.ts', '.jsx', '.js'];

function walk(dir, out = []) {
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return out; }
  for (const e of entries) {
    if (e.name === 'node_modules' || e.name.startsWith('.')) continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out);
    else if (CODE_EXT.includes(path.extname(e.name))) out.push(p);
  }
  return out;
}

/* Resolve a module specifier the way Metro would. */
function resolve(spec, fromFile) {
  let base;
  if (spec.startsWith('@/')) base = path.join(ROOT, spec.slice(2));
  else if (spec.startsWith('.')) base = path.resolve(path.dirname(fromFile), spec);
  else return { external: true };

  for (const ext of ['', ...CODE_EXT]) {
    const p = base + ext;
    if (fs.existsSync(p) && fs.statSync(p).isFile()) return { file: p };
  }
  for (const ext of CODE_EXT) {
    const p = path.join(base, 'index' + ext);
    if (fs.existsSync(p)) return { file: p };
  }
  // Asset imports (png/json/etc) resolve fine at build time
  if (/\.(png|jpg|jpeg|gif|svg|json|ttf|otf|mp4|webp|css)$/i.test(spec)) return { asset: true };
  return { missing: true, tried: base };
}

/* What does a file export by name? */
function exportsOf(file) {
  let src;
  try { src = fs.readFileSync(file, 'utf8'); } catch { return null; }
  const names = new Set();
  let m;

  // export function/class/const/let/var Foo
  const re1 = /export\s+(?:async\s+)?(?:function|class|const|let|var)\s+([A-Za-z_$][\w$]*)/g;
  while ((m = re1.exec(src))) names.add(m[1]);

  // export type/interface/enum Foo
  const re2 = /export\s+(?:type|interface|enum)\s+([A-Za-z_$][\w$]*)/g;
  while ((m = re2.exec(src))) names.add(m[1]);

  // export { A, B as C }
  const re3 = /export\s*(?:type\s*)?\{([^}]*)\}/g;
  while ((m = re3.exec(src))) {
    m[1].split(',').forEach(p => {
      const bit = p.trim().replace(/^type\s+/, '');
      if (!bit) return;
      const as = /\s+as\s+([\w$]+)$/.exec(bit);
      names.add(as ? as[1] : bit);
    });
  }

  if (/export\s+default/.test(src)) names.add('default');
  // export * from './x'  -> we cannot statically flatten; mark permissive
  const wildcard = /export\s*\*\s*from/.test(src);

  return { names, wildcard };
}

/* Parse imports out of a file. */
function importsOf(src) {
  const out = [];
  const re = /(?:^|\n)\s*import\s+(?!\()([\s\S]*?)\s+from\s+['"]([^'"]+)['"]/g;
  let m;
  while ((m = re.exec(src))) {
    const clause = m[1], spec = m[2];
    const named = [];
    const nb = /\{([\s\S]*?)\}/.exec(clause);
    if (nb) {
      nb[1].split(',').forEach(p => {
        const bit = p.trim();
        if (!bit) return;
        if (/^type\s/.test(bit)) return; // type-only, erased at runtime
        const as = /^([\w$]+)\s+as\s+/.exec(bit);
        named.push(as ? as[1] : bit.split(/\s+as\s+/)[0].trim());
      });
    }
    const hasDefault = !!clause.replace(/\{[\s\S]*?\}/g, '').replace(/\*\s+as\s+\w+/g, '').trim();
    const isTypeOnly = /^\s*type\s/.test(clause);
    out.push({ spec, named, hasDefault, isTypeOnly, at: m.index });
  }
  // re-exports count as real wiring:  export { X } from './x'
  const re3 = /(?:^|\n)\s*export\s+(?:\*|\{[\s\S]*?\})\s+from\s+['"]([^'"]+)['"]/g;
  while ((m = re3.exec(src))) out.push({ spec: m[1], named: [], hasDefault: false, reexport: true, at: m.index });

  // dynamic imports count as wiring:  React.lazy(() => import('./x'))
  const re4 = /\bimport\(\s*['"]([^'"]+)['"]\s*\)/g;
  while ((m = re4.exec(src))) out.push({ spec: m[1], named: [], hasDefault: false, dynamic: true, at: m.index });

  // bare side-effect imports:  import './x'
  const re2 = /(?:^|\n)\s*import\s+['"]([^'"]+)['"]/g;
  while ((m = re2.exec(src))) out.push({ spec: m[1], named: [], hasDefault: false, at: m.index });
  return out;
}

/* ── Run ───────────────────────────────────────────────────────── */
const files = SCAN_DIRS.map(d => path.join(ROOT, d)).filter(fs.existsSync).flatMap(d => walk(d));
const exportCache = new Map();
const importedFiles = new Set();

const brokenPaths = [];
const missingExports = [];

for (const file of files) {
  let src;
  try { src = fs.readFileSync(file, 'utf8'); } catch { continue; }
  const rel = path.relative(ROOT, file);

  for (const imp of importsOf(src)) {
    if (imp.isTypeOnly) continue;
    const r = resolve(imp.spec, file);
    if (r.external || r.asset) continue;

    const line = src.slice(0, imp.at).split('\n').length + 1;

    if (r.missing) {
      brokenPaths.push({ file: rel, spec: imp.spec, line, severity: 'FATAL',
        wouldThrow: `Unable to resolve module ${imp.spec}` });
      continue;
    }

    importedFiles.add(path.resolve(r.file));

    if (!imp.named.length) continue;
    if (!exportCache.has(r.file)) exportCache.set(r.file, exportsOf(r.file));
    const ex = exportCache.get(r.file);
    if (!ex || ex.wildcard) continue; // can't be sure — don't cry wolf

    for (const n of imp.named) {
      if (ex.names.has(n)) continue;
      // Used only in type positions (Foo[] , : Foo , <Foo> , as Foo)?
      // Then it is erased at compile time and cannot crash. Skip it.
      const valueUse = new RegExp(
        `(?:<${n}[\\s/>]|[^.\\w]${n}\\s*\\(|=\\s*${n}[^\\w]|\\b${n}\\.[a-z])`
      ).test(src);
      if (!valueUse) continue;
      {
        missingExports.push({
          file: rel, line, imported: n,
          from: path.relative(ROOT, r.file),
          severity: 'CRASH',
          wouldThrow: `Element type is invalid ... got: undefined  (${n})`,
        });
      }
    }
  }
}

/* Unwired component files — reported, NEVER deleted. */
const unwired = files
  .filter(f => /[\\/]components[\\/]/.test(f) && path.extname(f) === '.tsx')
  .filter(f => !importedFiles.has(path.resolve(f)))
  .filter(f => !/index\.tsx?$/.test(f))
  .map(f => path.relative(ROOT, f));

const report = {
  scannedAt: new Date().toISOString(),
  root: ROOT,
  filesScanned: files.length,
  brokenPaths, missingExports, unwiredComponents: unwired,
  verdict: brokenPaths.length ? 'FATAL' : missingExports.length ? 'CRASH RISK' : 'CLEAN',
};

try { fs.writeFileSync(path.join(ROOT, 'nexus-deepscan-report.json'), JSON.stringify(report, null, 2)); } catch {}

const bar = '─'.repeat(66);
console.log(bar);
console.log('NEXUS DEEP SCAN  ·  import graph audit  ·  READ-ONLY');
console.log(bar);
console.log(`Files scanned        : ${report.filesScanned}`);
console.log(`[A] Broken paths     : ${brokenPaths.length}   (fatal — whole app dies)`);
console.log(`[B] Missing exports  : ${missingExports.length}   (crash — same bug as PerformanceStrip)`);
console.log(`[C] Unwired files    : ${unwired.length}   (not a crash — nothing deleted)`);

if (brokenPaths.length) {
  console.log('\n[A] BROKEN IMPORT PATHS — app will not boot:');
  brokenPaths.forEach(b => console.log(`  ✗ ${b.file}:${b.line}  ->  '${b.spec}'`));
}
if (missingExports.length) {
  console.log('\n[B] IMPORTED BUT NOT EXPORTED — renders as undefined:');
  missingExports.forEach(x =>
    console.log(`  ✗ ${x.file}:${x.line}  { ${x.imported} }  not exported by  ${x.from}`));
}
if (unwired.length) {
  console.log('\n[C] BUILT BUT NEVER WIRED UP — review, do not delete:');
  unwired.slice(0, 40).forEach(u => console.log(`  · ${u}`));
  if (unwired.length > 40) console.log(`  ... and ${unwired.length - 40} more (see JSON)`);
}

console.log(`\nVERDICT: ${report.verdict}`);
console.log(bar);
process.exit(brokenPaths.length || missingExports.length ? 1 : 0);
