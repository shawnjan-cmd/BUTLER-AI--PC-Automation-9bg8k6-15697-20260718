#!/usr/bin/env node
/**
 * nexus-autofix.js — STARTUP CRASH SCANNER + AUTO-FIX
 * ------------------------------------------------------------------
 * Finds every JSX component that is USED but never IMPORTED or DEFINED.
 * These are the exact things that throw "X is not defined" and crash a tab
 * at startup — the class of bug that killed your CORE tab.
 *
 *   node tools/nexus-autofix.js              # scan only, report
 *   node tools/nexus-autofix.js --strip      # PERMANENTLY REMOVE the usages
 *   node tools/nexus-autofix.js --strip --backup
 *
 * --strip rewrites the JSX so the broken component is deleted from the tree.
 * Self-closing tags are removed outright. Paired tags have their children
 * preserved and only the wrapper removed, so you never lose content.
 *
 * Writes nexus-startup-report.json next to the project root.
 */

const fs = require('fs');
const path = require('path');

const ROOT   = process.argv.find(a => a.startsWith('--root='))?.split('=')[1] || process.cwd();
const STRIP  = process.argv.includes('--strip');
const BACKUP = process.argv.includes('--backup');

const SCAN_DIRS = ['app', 'components', 'screens', 'src'];
const EXT = new Set(['.tsx', '.jsx']);

/* Names that are always available and must never be flagged. */
const ALWAYS_OK = new Set([
  'React', 'Fragment', 'Suspense', 'StrictMode', 'Profiler', 'Component',
  'Children', 'Provider', 'Consumer',
]);

function walk(dir, out = []) {
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return out; }
  for (const e of entries) {
    if (e.name === 'node_modules' || e.name.startsWith('.')) continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out);
    else if (EXT.has(path.extname(e.name))) out.push(p);
  }
  return out;
}

/* ── Collect every identifier that is legitimately in scope ────── */
function declaredNames(src) {
  const names = new Set(ALWAYS_OK);
  const add = n => n && names.add(n.trim());

  // import Default, { A, B as C }, * as NS from '...'
  const importRe = /(?:^|\n)\s*import\s+(?!\()([\s\S]*?)\s+from\s+['"][^'"]+['"]/g;
  let m;
  while ((m = importRe.exec(src))) {
    const clause = m[1];
    // namespace
    const ns = /\*\s+as\s+(\w+)/.exec(clause);
    if (ns) add(ns[1]);
    // named block
    const named = /\{([\s\S]*?)\}/.exec(clause);
    if (named) {
      named[1].split(',').forEach(part => {
        const bit = part.trim();
        if (!bit) return;
        const as = /(?:\w+)\s+as\s+(\w+)/.exec(bit);
        add(as ? as[1] : bit.replace(/^type\s+/, ''));
      });
    }
    // default
    const def = clause.replace(/\{[\s\S]*?\}/g, '').replace(/\*\s+as\s+\w+/g, '');
    def.split(',').forEach(part => {
      const bit = part.trim();
      if (bit && /^[A-Za-z_$][\w$]*$/.test(bit)) add(bit);
    });
  }

  // const X = require(...) / const { A, B } = require(...)
  const reqRe = /(?:const|let|var)\s+(\{[^}]*\}|[\w$]+)\s*=\s*require\(/g;
  while ((m = reqRe.exec(src))) {
    const t = m[1];
    if (t.startsWith('{')) t.slice(1, -1).split(',').forEach(p => add(p.split(':').pop()));
    else add(t);
  }

  // array destructuring: const [Foo, setFoo] = useState()
  const arrRe = /(?:const|let|var)\s*\[([^\]]{0,200})\]\s*=/g;
  while ((m = arrRe.exec(src))) {
    m[1].split(',').forEach(p => add(p.split('=')[0].trim()));
  }

  // local declarations
  const declRe = /(?:^|\n)\s*(?:export\s+)?(?:default\s+)?(?:function|class|const|let|var)\s+([A-Za-z_$][\w$]*)/g;
  while ((m = declRe.exec(src))) add(m[1]);

  // function params / destructured locals that could hold components
  const paramRe = /(?:function\s*\w*\s*\(|=>\s*|\(\s*)\{([^}]{0,300})\}/g;
  while ((m = paramRe.exec(src))) {
    m[1].split(',').forEach(p => {
      const bit = p.split(':').pop().split('=')[0].trim();
      if (/^[A-Z][\w$]*$/.test(bit)) add(bit);
    });
  }

  return names;
}

/* ── Blank out comments and string literals ─────────────────────
 * Replaces their contents with spaces so all byte offsets stay valid.
 * Without this, JSDoc examples like "<ScrollView/>" get flagged as
 * real crashes. */
function mask(src) {
  let out = src.split('');
  let i = 0;
  const n = src.length;
  const blank = (a, b) => { for (let k = a; k < b && k < n; k++) if (out[k] !== '\n') out[k] = ' '; };

  while (i < n) {
    const c = src[i], d = src[i + 1];
    if (c === '/' && d === '/') { let j = src.indexOf('\n', i); if (j === -1) j = n; blank(i, j); i = j; continue; }
    if (c === '/' && d === '*') { let j = src.indexOf('*/', i + 2); j = j === -1 ? n : j + 2; blank(i, j); i = j; continue; }
    if (c === '"' || c === "'" || c === '`') {
      let j = i + 1;
      while (j < n) {
        if (src[j] === '\\') { j += 2; continue; }
        if (src[j] === c) { j++; break; }
        j++;
      }
      blank(i + 1, j - 1); i = j; continue;
    }
    i++;
  }
  return out.join('');
}

/* ── Collect JSX component usages ──────────────────────────────── */
function usedComponents(raw) {
  const src = mask(raw);
  const used = new Map(); // name -> [indices]
  const re = /<([A-Z][A-Za-z0-9_$]*)(?:\.[A-Za-z0-9_$]+)?(\s[^<>]*?)?(\/?)>/g;
  let m;
  while ((m = re.exec(src))) {
    const at = m.index;

    // REJECT TypeScript generics. In real JSX, '<' is never directly
    // preceded by an identifier char, '>', '.', or ':'.
    //   useState<SyncStatus>   Record<Tab, X>   React.FC<Props>
    const prev = src.slice(Math.max(0, at - 1), at);
    if (/[\w$>.\]]/.test(prev)) continue;

    // REJECT type annotations:  ): <Foo>  /  as <Foo>  /  extends <Foo>
    const before = src.slice(Math.max(0, at - 24), at);
    if (/(?::|\bas|\bextends|\bimplements|\bsatisfies)\s*$/.test(before)) continue;

    // A real JSX tag either self-closes, has props, or has a matching
    // closing tag somewhere after it. Generics have none of these.
    // REJECT generic type params:  <K extends keyof X>  /  <T,>
    if (m[2] && /^\s*(extends|,)\b/.test(m[2])) continue;

    const name = m[1];
    const selfClosing = m[3] === '/';
    const hasProps = !!(m[2] && m[2].trim());
    const hasClose = src.indexOf(`</${name}>`, at) !== -1;
    if (!selfClosing && !hasProps && !hasClose) continue;

    if (!used.has(name)) used.set(name, []);
    used.get(name).push(at);
  }
  return used;
}

/* ── Strip a broken component from the JSX tree ────────────────── */
function stripComponent(src, name) {
  let out = src, changed = 0;

  // 1. Self-closing: <Foo ... />
  const selfRe = new RegExp(`<${name}\\b[^>]*?/>`, 'g');
  out = out.replace(selfRe, () => { changed++; return ''; });

  // 2. Paired with no children: <Foo ...></Foo>
  const emptyRe = new RegExp(`<${name}\\b[^>]*?>\\s*</${name}>`, 'g');
  out = out.replace(emptyRe, () => { changed++; return ''; });

  // 3. Paired with children — unwrap, keep the children.
  let guard = 0;
  while (guard++ < 50) {
    const open = new RegExp(`<${name}\\b[^>]*?>`);
    const om = open.exec(out);
    if (!om) break;
    const closeTag = `</${name}>`;
    const start = om.index;
    const afterOpen = start + om[0].length;
    const end = out.indexOf(closeTag, afterOpen);
    if (end === -1) break;
    const children = out.slice(afterOpen, end);
    out = out.slice(0, start) + children + out.slice(end + closeTag.length);
    changed++;
  }

  // 4. Tidy: collapse the blank lines the removal left behind
  out = out.replace(/\n[ \t]*\n[ \t]*\n+/g, '\n\n');

  return { out, changed };
}

/* ── Main ──────────────────────────────────────────────────────── */
const files = SCAN_DIRS
  .map(d => path.join(ROOT, d))
  .filter(fs.existsSync)
  .flatMap(d => walk(d));

const report = {
  scannedAt: new Date().toISOString(),
  root: ROOT,
  filesScanned: files.length,
  mode: STRIP ? 'STRIP (destructive)' : 'SCAN (read-only)',
  crashRisks: [],
  stripped: [],
  clean: true,
};

for (const file of files) {
  let src;
  try { src = fs.readFileSync(file, 'utf8'); } catch { continue; }

  const declared = declaredNames(src);
  const used = usedComponents(src);

  const missing = [...used.keys()].filter(n => !declared.has(n));
  if (!missing.length) continue;

  report.clean = false;
  const rel = path.relative(ROOT, file);

  for (const name of missing) {
    const line = src.slice(0, used.get(name)[0]).split('\n').length;
    report.crashRisks.push({
      file: rel,
      component: name,
      firstUsedAtLine: line,
      occurrences: used.get(name).length,
      wouldThrow: `${name} is not defined`,
      severity: 'CRASH',
    });
  }

  if (STRIP) {
    if (BACKUP) { try { fs.writeFileSync(file + '.bak', src); } catch {} }
    let next = src, total = 0;
    for (const name of missing) {
      const r = stripComponent(next, name);
      next = r.out; total += r.changed;
    }
    if (next !== src) {
      fs.writeFileSync(file, next);
      report.stripped.push({ file: rel, components: missing, edits: total });
    }
  }
}

/* ── Output ────────────────────────────────────────────────────── */
const out = path.join(ROOT, 'nexus-startup-report.json');
try { fs.writeFileSync(out, JSON.stringify(report, null, 2)); } catch {}

const bar = '─'.repeat(64);
console.log(bar);
console.log('NEXUS STARTUP SCAN  ·  ' + report.mode);
console.log(bar);
console.log(`Files scanned : ${report.filesScanned}`);
console.log(`Crash risks   : ${report.crashRisks.length}`);

if (!report.crashRisks.length) {
  console.log('\n  ✓ STARTUP CLEAN — no undefined components. No tab will crash.\n');
} else {
  console.log('');
  for (const r of report.crashRisks) {
    console.log(`  ✗ ${r.file}:${r.firstUsedAtLine}`);
    console.log(`      <${r.component}/>  ->  "${r.wouldThrow}"  (${r.occurrences}x)`);
  }
  console.log('');
  if (STRIP) {
    console.log(`  ✓ PERMANENTLY REMOVED from ${report.stripped.length} file(s).`);
    console.log('    Re-run without --strip to confirm the app is clean.\n');
  } else {
    console.log('  Run again with --strip to permanently remove them.\n');
  }
}
console.log(`Report written: ${out}`);
console.log(bar);

process.exit(report.crashRisks.length && !STRIP ? 1 : 0);
