/**
 * NexusVitals — HUD GAUGES + SYSTEM VITALS GRID
 * ------------------------------------------------------------------
 * Built to the "NEXUS COMMAND — Complete Visual System" spec
 * (§2.6 HUD Mission Critical, §2.7 System Vitals Grid), rebuilt as a
 * single self-contained file using the sparkline/ring patterns from
 * CircularMetricRing.tsx and PerformanceMonitorWidget.tsx.
 *
 * SAFETY CONTRACT — same as PerformanceStrip:
 *   • Imports only react, react-native, react-native-svg, @expo/vector-icons.
 *   • Every prop optional. Undefined/NaN renders "--". Never throws.
 *   • Named AND default exports.
 *
 * Usage:
 *   import { NexusHudGauges, NexusSystemVitals } from '@/components/ui/NexusVitals';
 *   <NexusHudGauges cpu={41} ram={63} disk={22} gpu={8} />
 *   <NexusSystemVitals live />
 *
 * If react-native-svg is unavailable the gauges degrade to bar meters
 * automatically instead of crashing.
 */

import React, { useMemo } from 'react';
import { View, Text, StyleSheet, Platform } from 'react-native';

const MONO: any = Platform.OS === 'ios' ? 'Menlo-Bold' : 'monospace';

/* ── Spec palette (§1.2 / §1.3) ─────────────────────────────────── */
const C = {
  screen:  '#0B0F19',
  card:    '#131824',
  border:  'rgba(255,255,255,0.04)',
  idle:    '#1F2937',
  white:   '#FFFFFF',
  label:   '#9CA3AF',
  body:    '#6B7280',
  cyan:    '#00E5FF',
  purple:  '#A855F7',
  green:   '#22C55E',
  orange:  '#F97316',
  blue:    '#3B82F6',
  teal:    '#14B8A6',
  red:     '#EF4444',
  liveBg:  '#064E3B',
};

/* ── Guarded SVG load ───────────────────────────────────────────── */
let Svg: any = null, SvgPath: any = null, SvgCircle: any = null, SvgPolyline: any = null;
try {
  const m = require('react-native-svg');
  Svg = m.default ?? m.Svg;
  SvgPath = m.Path; SvgCircle = m.Circle; SvgPolyline = m.Polyline;
} catch { /* degrade to bars */ }

const HAS_SVG = !!(Svg && SvgPath);

const num = (v: any) => (Number.isFinite(Number(v)) ? Number(v) : -1);
const pctTxt = (v: number) => (v >= 0 ? `${Math.round(v)}%` : '--');

/* ═══ HUD GAUGES (§2.6) ═════════════════════════════════════════ */

function SemiGauge({ value, accent, label }: { value: number; accent: string; label: string }) {
  const v = Math.max(0, Math.min(100, value));
  const size = 62, r = 24, cx = size / 2, cy = size / 2 + 6;

  // 180° arc, sweeping left→right
  const arc = `M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`;

  // Pointer position along the arc
  const theta = Math.PI - (v / 100) * Math.PI;
  const px = cx + r * Math.cos(theta);
  const py = cy - r * Math.sin(theta);

  return (
    <View style={g.gauge}>
      {HAS_SVG ? (
        <Svg width={size} height={size * 0.72}>
          <SvgPath d={arc} stroke={C.idle} strokeWidth={4} fill="none" strokeLinecap="round" />
          {value >= 0 && (
            <SvgPath d={arc} stroke={accent} strokeWidth={3} fill="none" strokeLinecap="round"
              strokeDasharray={`${(v / 100) * Math.PI * r} ${Math.PI * r}`} opacity={0.75} />
          )}
          {value >= 0 && <SvgCircle cx={px} cy={py} r={3} fill={accent} />}
        </Svg>
      ) : (
        <View style={g.fallbackTrack}>
          <View style={[g.fallbackFill, {
            width: `${value >= 0 ? v : 0}%`, backgroundColor: accent,
          }]} />
        </View>
      )}
      <Text style={[g.gaugeVal, { color: value >= 0 ? C.white : C.body }]}>{pctTxt(value)}</Text>
      <Text style={g.gaugeLabel}>{label}</Text>
    </View>
  );
}

export interface NexusHudGaugesProps {
  cpu?: number; ram?: number; disk?: number; gpu?: number; style?: any;
}

export function NexusHudGauges({ cpu, ram, disk, gpu, style }: NexusHudGaugesProps = {}) {
  const gauges = [
    { label: 'CPU',  v: num(cpu),  a: C.cyan   },
    { label: 'RAM',  v: num(ram),  a: C.blue   },
    { label: 'DISK', v: num(disk), a: C.orange },
    { label: 'GPU',  v: num(gpu),  a: C.purple },
  ];

  return (
    <View style={[g.card, style]}>
      <View style={g.headerRow}>
        <Text style={g.header}>HUD</Text>
        <View style={g.headerDot} />
        <Text style={g.header}>MISSION CRITICAL</Text>
      </View>
      <View style={g.gaugeRow}>
        {gauges.map(x => <SemiGauge key={x.label} value={x.v} accent={x.a} label={x.label} />)}
      </View>
    </View>
  );
}

/* ═══ SYSTEM VITALS GRID (§2.7) ═════════════════════════════════ */

function Sparkline({ points, color }: { points: number[]; color: string }) {
  const W = 120, H = 26;
  const path = useMemo(() => {
    if (!points?.length) return '';
    const max = Math.max(...points, 1), min = Math.min(...points, 0);
    const span = max - min || 1;
    return points
      .map((p, i) => {
        const x = (i / (points.length - 1 || 1)) * W;
        const y = H - ((p - min) / span) * H;
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  }, [points]);

  if (!HAS_SVG || !path) return <View style={{ height: H }} />;
  return (
    <Svg width="100%" height={H} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
      <SvgPolyline points={path} fill="none" stroke={color} strokeWidth={2}
        strokeLinejoin="round" strokeLinecap="round" opacity={0.9} />
    </Svg>
  );
}

function VitalCard({ title, value, trend, accent, series }: any) {
  const hasVal = value !== undefined && value !== null && value !== '--';
  return (
    <View style={v.card}>
      <View style={v.cardTop}>
        <Text style={v.cardTitle} numberOfLines={1}>{title}</Text>
        <Text style={[v.cardVal, { color: hasVal ? accent : C.white }]} numberOfLines={1}>
          {hasVal ? String(value) : '--'}
        </Text>
      </View>
      <Text style={[v.trend, { color: accent }]} numberOfLines={1}>{trend}</Text>
      <Sparkline points={series} color={accent} />
    </View>
  );
}

/** Deterministic pseudo-telemetry so the sparklines look alive offline. */
function seed(n: number, base: number, spread: number) {
  const out: number[] = [];
  let x = n * 9301;
  for (let i = 0; i < 20; i++) {
    x = (x * 9301 + 49297) % 233280;
    out.push(base + (x / 233280) * spread);
  }
  return out;
}

export interface NexusSystemVitalsProps {
  uptime?: string | number;
  requests?: string | number;
  latency?: string | number;
  errors?: string | number;
  live?: boolean;
  style?: any;
}

export function NexusSystemVitals({
  uptime, requests, latency, errors, live = false, style,
}: NexusSystemVitalsProps = {}) {
  const cards = [
    { title: 'UPTIME',   value: uptime,   trend: '++0.02%', accent: C.green,  series: seed(1, 60, 30) },
    { title: 'REQUESTS', value: requests, trend: '++12%',   accent: C.blue,   series: seed(2, 30, 60) },
    { title: 'LATENCY',  value: latency,  trend: '-6ms',    accent: C.teal,   series: seed(3, 40, 40) },
    { title: 'ERRORS',   value: errors,   trend: '-0.01%',  accent: C.red,    series: seed(4, 10, 20) },
  ];

  return (
    <View style={style}>
      <View style={v.sectionRow}>
        <Text style={v.section}>SYSTEM VITALS</Text>
        <View style={[v.liveBadge, !live && { backgroundColor: 'rgba(107,114,128,0.15)' }]}>
          <View style={[v.liveDot, { backgroundColor: live ? C.green : C.body }]} />
          <Text style={[v.liveTxt, { color: live ? C.green : C.body }]}>
            {live ? 'LIVE' : 'IDLE'}
          </Text>
        </View>
      </View>
      <View style={v.grid}>
        {cards.map(c => <VitalCard key={c.title} {...c} />)}
      </View>
    </View>
  );
}

export default NexusSystemVitals;

/* ── Styles ─────────────────────────────────────────────────────── */
const g = StyleSheet.create({
  card: {
    backgroundColor: C.card, borderRadius: 12, borderWidth: 1, borderColor: C.border,
    padding: 16, marginBottom: 14,
  },
  headerRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 12 },
  header:    { color: C.white, fontSize: 13, fontWeight: '700', letterSpacing: 1.5, fontFamily: MONO },
  headerDot: { width: 4, height: 4, borderRadius: 2, backgroundColor: C.body },
  gaugeRow:  { flexDirection: 'row', justifyContent: 'space-between' },
  gauge:     { alignItems: 'center', flex: 1 },
  gaugeVal:  { fontSize: 16, fontWeight: '700', fontFamily: MONO, marginTop: -6 },
  gaugeLabel:{ color: C.label, fontSize: 11, fontWeight: '600', fontFamily: MONO, marginTop: 4, letterSpacing: 0.5 },
  fallbackTrack: { width: '80%', height: 6, borderRadius: 3, backgroundColor: C.idle, marginBottom: 8, overflow: 'hidden' },
  fallbackFill:  { height: '100%', borderRadius: 3 },
});

const v = StyleSheet.create({
  sectionRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  section:    { color: C.white, fontSize: 13, fontWeight: '700', letterSpacing: 1.5, fontFamily: MONO },
  liveBadge:  { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: C.liveBg, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  liveDot:    { width: 6, height: 6, borderRadius: 3 },
  liveTxt:    { fontSize: 10, fontWeight: '700', letterSpacing: 1, fontFamily: MONO },
  grid:       { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  card:       { width: '48.5%', minHeight: 106, backgroundColor: C.card, borderRadius: 12, borderWidth: 1, borderColor: C.border, padding: 10, marginBottom: 10, justifyContent: 'space-between' },
  cardTop:    { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' },
  cardTitle:  { color: C.label, fontSize: 10, fontWeight: '600', letterSpacing: 1, fontFamily: MONO, flexShrink: 1 },
  cardVal:    { fontSize: 20, fontWeight: '700', fontFamily: MONO },
  trend:      { fontSize: 11, fontWeight: '600', letterSpacing: 0.5, fontFamily: MONO, marginTop: 2 },
});
