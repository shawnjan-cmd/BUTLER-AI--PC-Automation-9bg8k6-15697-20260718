/**
 * GlobalComponentShim — THE ZERO-EDIT CRASH KILLER
 * ------------------------------------------------------------------
 * WHY THIS EXISTS
 * ---------------
 * "PerformanceStrip is not defined" is a ReferenceError. It happens when
 * JSX like <PerformanceStrip /> compiles to a BARE identifier that was
 * never imported in that file. In JavaScript, a bare identifier that is
 * not declared in any enclosing scope falls through to the GLOBAL object
 * at runtime.
 *
 * So: if we assign the component onto globalThis BEFORE the screen renders,
 * the bare reference resolves and the crash disappears — WITHOUT editing
 * the file that uses it.
 *
 * HOW TO ACTIVATE (one line, in app/_layout.tsx, ABOVE every other import
 * that could render a screen):
 *
 *     import '@/components/ui/GlobalComponentShim';
 *
 * That is the entire fix. Everything below is defensive.
 *
 * It also registers a set of harmless placeholders for other component
 * names that have gone missing in past builds, so a future typo degrades
 * into "nothing renders" instead of "tab crashed".
 */

import React from 'react';
import { View } from 'react-native';
import { PerformanceStrip } from './PerformanceStrip';

const g: any =
  (typeof globalThis !== 'undefined' && globalThis) ||
  (typeof global !== 'undefined' && (global as any)) ||
  {};

/** Renders nothing. Used as a safe stand-in for any missing component. */
const NullComponent: React.FC<any> = () => null;

/** A visible-but-harmless spacer, for layout-critical slots. */
const NullBlock: React.FC<any> = () => <View style={{ height: 0 }} />;

/** Only define if not already defined — never clobber a real import. */
function register(name: string, value: any) {
  try {
    if (g[name] === undefined || g[name] === null) {
      Object.defineProperty(g, name, {
        value,
        writable: true,
        configurable: true,
        enumerable: false,
      });
    }
  } catch {
    try { g[name] = value; } catch {}
  }
}

/* ── THE ACTUAL FIX ─────────────────────────────────────────────── */
register('PerformanceStrip', PerformanceStrip);

/* ── Defensive placeholders for other historically-missing names ── */
const MAYBE_MISSING = [
  'PerformanceMonitorWidget',
  'PerformanceBar',
  'PerfStrip',
  'MetricStrip',
  'SystemVitals',
  'SystemVitalsGrid',
  'HudGauges',
  'ResourceCards',
  'MetricBar',
  'ConnectedPCCard',
  'ButlerAICard',
  'FeatureIconGrid',
  'GlowRing',
  'SparkLine',
  'Sparkline',
  'StatusPill',
  'LiveBadge',
];

for (const name of MAYBE_MISSING) register(name, NullComponent);

register('__NexusNullComponent', NullComponent);
register('__NexusNullBlock', NullBlock);

/**
 * Runtime helper: <Safe of={Maybe} {...props} />
 * Renders `of` when it is a real component, otherwise renders nothing.
 * Use this anywhere you are unsure a component actually exists.
 */
export function Safe({ of: Cmp, fallback = null, ...rest }: any) {
  if (typeof Cmp === 'function' || (Cmp && typeof Cmp === 'object' && (Cmp as any).$$typeof)) {
    try { return <Cmp {...rest} />; } catch { return fallback; }
  }
  return fallback;
}

register('Safe', Safe);

export { NullComponent, NullBlock, PerformanceStrip };
export default {};
