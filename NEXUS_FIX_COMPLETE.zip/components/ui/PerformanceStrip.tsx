/**
 * PerformanceStrip — STANDALONE / CRASH-PROOF
 * ------------------------------------------------------------------
 * Fixes: "PerformanceStrip is not defined" (CORE TAB CRASHED)
 *
 * The old PerformanceStrip lived INSIDE PerformanceMonitorWidget.tsx and
 * was never re-exported from components/ui/index.ts, so any <PerformanceStrip/>
 * usage resolved to `undefined` -> ReferenceError -> TabErrorBoundary.
 *
 * This version:
 *   • Has ZERO app-internal imports (no @/services, no expo-router).
 *     It cannot crash from a missing service.
 *   • EVERY prop is optional. Missing/NaN/negative values render "--".
 *   • Live data is pulled via a guarded require() that silently no-ops.
 *   • Exported BOTH named and default so any import style works.
 *
 * Usage (any of these work):
 *   import { PerformanceStrip } from '@/components/ui';
 *   import { PerformanceStrip } from '@/components/ui/PerformanceStrip';
 *   import PerformanceStrip from '@/components/ui/PerformanceStrip';
 *
 *   <PerformanceStrip />                                  // auto-polls
 *   <PerformanceStrip cpu={42} ram={68} disk={31} isConnected />
 */

import React, { useRef, useEffect, useState } from 'react';
import { View, Text, StyleSheet, Platform, Animated } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

const MONO: any = Platform.OS === 'ios' ? 'Menlo-Bold' : 'monospace';

/* ─── NEXUS palette (matches nexushome.tsx) ─────────────────────── */
const P = {
  cyan:   '#00C8E0',
  teal:   '#00D4AA',
  green:  '#00CC96',
  amber:  '#F5A820',
  red:    '#FF4060',
  purple: '#9B6AFF',
  dim:    '#2A3A50',
  mid:    '#5A7888',
  track:  'rgba(255,255,255,0.06)',
  surface:'rgba(10,20,32,0.85)',
  border: 'rgba(0,200,224,0.14)',
};

/* ─── Threshold coloring ────────────────────────────────────────── */
function barColor(pct: number, kind: 'cpu' | 'ram' | 'disk'): string {
  if (!Number.isFinite(pct) || pct < 0) return P.dim;
  const hot  = kind === 'disk' ? 90 : 85;
  const warm = kind === 'disk' ? 75 : 65;
  if (pct >= hot)  return P.red;
  if (pct >= warm) return P.amber;
  if (kind === 'cpu')  return P.cyan;
  if (kind === 'ram')  return P.teal;
  return P.purple;
}

const ICONS: Record<string, any> = {
  CPU:  'memory',
  RAM:  'sd-card',
  DISK: 'storage',
  GPU:  'developer-board',
  NET:  'wifi',
};

/* ─── Single animated mini bar ──────────────────────────────────── */
function BarMini({ pct, label }: { pct: number; label: string }) {
  const safe = Number.isFinite(pct) ? Math.max(0, Math.min(100, pct)) : -1;
  const col  = barColor(safe, label.toLowerCase() as any);
  const anim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    let cancelled = false;
    const t = Animated.timing(anim, {
      toValue: safe > 0 ? safe : 0,
      duration: 800,
      useNativeDriver: false, // width animation cannot use native driver
    });
    t.start(() => { if (cancelled) anim.stopAnimation(); });
    return () => { cancelled = true; try { t.stop(); } catch {} };
  }, [safe]);

  const width = anim.interpolate({
    inputRange: [0, 100],
    outputRange: ['0%', '100%'],
    extrapolate: 'clamp',
  });

  return (
    <View style={s.item}>
      <MaterialIcons name={ICONS[label] ?? 'memory'} size={10} color={col} />
      <Text style={[s.label, { color: col + 'A0' }]} numberOfLines={1}>{label}</Text>
      <View style={s.track}>
        <Animated.View style={[s.fill, { width: width as any, backgroundColor: col }]} />
      </View>
      <Text style={[s.pct, { color: col }]} numberOfLines={1}>
        {safe >= 0 ? `${Math.round(safe)}%` : '--'}
      </Text>
    </View>
  );
}

/* ─── Optional live poll (never throws, never required) ─────────── */
function useLiveStats(enabled: boolean) {
  const [stats, setStats] = useState<{ cpu: number; ram: number; disk: number; on: boolean }>(
    { cpu: -1, ram: -1, disk: -1, on: false }
  );

  useEffect(() => {
    if (!enabled) return;
    let alive = true;

    const read = async () => {
      try {
        const mod = require('@/services/serverConnection');
        const sc  = mod?.serverConnection ?? mod?.default;
        if (!sc) return;
        const on = typeof sc.isConnected === 'function' ? !!sc.isConnected() : !!sc.isConnected;
        let m: any = null;
        if (typeof sc.getMetrics === 'function')            m = await sc.getMetrics();
        else if (typeof sc.getSystemStats === 'function')   m = await sc.getSystemStats();
        else if (typeof sc.getLastMetrics === 'function')   m = sc.getLastMetrics();
        if (!alive) return;
        setStats({
          cpu:  Number(m?.cpu  ?? m?.cpuPercent  ?? -1),
          ram:  Number(m?.ram  ?? m?.memPercent  ?? m?.memory ?? -1),
          disk: Number(m?.disk ?? m?.diskPercent ?? -1),
          on,
        });
      } catch { /* service missing or offline — stay at "--" */ }
    };

    read();
    const id = setInterval(read, 4000);
    return () => { alive = false; clearInterval(id); };
  }, [enabled]);

  return stats;
}

/* ─── Public component ──────────────────────────────────────────── */
export interface PerformanceStripProps {
  cpu?: number;
  ram?: number;
  disk?: number;
  isConnected?: boolean;
  /** Poll serverConnection when values are not passed in. Default true. */
  live?: boolean;
  style?: any;
}

export function PerformanceStrip(props: PerformanceStripProps = {}) {
  const {
    cpu, ram, disk, isConnected,
    live = cpu === undefined && ram === undefined && disk === undefined,
    style,
  } = props ?? {};

  const auto = useLiveStats(!!live);

  const vCpu  = cpu  !== undefined ? cpu  : auto.cpu;
  const vRam  = ram  !== undefined ? ram  : auto.ram;
  const vDisk = disk !== undefined ? disk : auto.disk;
  const on    = isConnected !== undefined ? !!isConnected : auto.on;

  return (
    <View style={[s.wrap, style]}>
      <View style={[s.dot, { backgroundColor: on ? P.green : P.dim }]} />
      <BarMini pct={vCpu}  label="CPU" />
      <View style={s.div} />
      <BarMini pct={vRam}  label="RAM" />
      <View style={s.div} />
      <BarMini pct={vDisk} label="DISK" />
    </View>
  );
}

export default PerformanceStrip;

const s = StyleSheet.create({
  wrap: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: P.surface,
    borderWidth: 1,
    borderColor: P.border,
    borderRadius: 10,
    paddingVertical: 7,
    paddingHorizontal: 10,
    gap: 8,
    marginBottom: 10,
  },
  dot:  { width: 7, height: 7, borderRadius: 4, flexShrink: 0 },
  div:  { width: 1, height: 14, backgroundColor: 'rgba(255,255,255,0.07)' },
  item: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 4 },
  label:{ fontSize: 8, fontFamily: MONO, letterSpacing: 0.4, fontWeight: '700' },
  track:{ flex: 1, height: 3, borderRadius: 2, backgroundColor: P.track, overflow: 'hidden' },
  fill: { height: '100%', borderRadius: 2 },
  pct:  { fontSize: 9, fontFamily: MONO, fontWeight: '800', minWidth: 26, textAlign: 'right' },
});
