// Butler AI — UI Component Exports
// v2: adds the exports that were missing and causing
//     "PerformanceStrip is not defined" / "Element type is invalid".

export { NexusLiveCard, NexusMetricPillRow, NexusStatusBanner } from './NexusLiveCard';
export type { NexusLiveCardStat, MetricPill } from './NexusLiveCard';
export { NexusGlowButton } from './NexusGlowButton';
export { TabSwipeOverlay } from './TabSwipeOverlay';
export { NexusPageBanner } from './NexusPageBanner';
export { CompactPageHeader } from './CompactPageHeader';
export { RemoteAccessCard } from './RemoteAccessCard';
export { GeminiKeyCard } from './GeminiKeyCard';
export { MasterJsonPanel } from './MasterJsonPanel';
export { AppVersionBanner, AppVersionCard, APP_VERSION, checkServerVersion } from './AppVersionGuard';
export { TitanProtocolCard } from './TitanProtocolCard';

/* ── ADDED IN v2 — these were the missing pieces ────────────────── */

// The crash fix. Standalone, zero-dependency, crash-proof.
export { PerformanceStrip } from './PerformanceStrip';
export type { PerformanceStripProps } from './PerformanceStrip';

// The full widget the strip was previously buried inside.
export { PerformanceMonitorWidget } from './PerformanceMonitorWidget';

// Error handling — now exported so any screen can wrap itself.
export { TabErrorBoundary } from './TabErrorBoundary';

// Safety helper: <Safe of={MaybeUndefinedComponent} />
export { Safe, NullComponent } from './GlobalComponentShim';

// HUD gauges + System Vitals grid (NEXUS COMMAND spec §2.6 / §2.7)
export { NexusHudGauges, NexusSystemVitals } from './NexusVitals';
